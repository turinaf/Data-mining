This django web app project
Djang must be installed to run it.
Then create virtual environment. Since we installed django in Anaconda virtual environment, it's recommended that you use anaconda too.
 Then run the following command

python manage.py runserver